import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Gui extends JFrame {

    JTextField screen;
    JButton volumeup, volumedown, makecall;
    JButton zero, one, two, three, four, five, six, seven, eight, nine, star,htag;
    JRadioButton speakeron, speakeroff;
    ButtonGroup speakergroup;
    String Value;

    public Gui(){
        //1 set the layout of the Gui
        /******************Screen Part********************/
        this.setLayout(new BorderLayout());
        //2 create a screen and add it to the Gui
        /******************Make Call Part********************/
        screen = new JTextField();
        screen.setPreferredSize(new Dimension(300,80));
        this.add(screen, BorderLayout.NORTH);
        //3 create a makecall button and add it to the Gui
        /******************Speaker Part********************/
        makecall = new JButton("Make a Call");
        makecall.setPreferredSize(new Dimension(300,100));
        this.add(makecall,BorderLayout.SOUTH);
        makecall.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	              //insert the action here
	    		  	JFrame frame = new JFrame("JButton listener"); 
	    	        //8 create volume buttons
	    		  	JButton OK = new JButton("ok");
	    		  	JButton cancel = new JButton("CANCEL");

	    	        JPanel panel = new JPanel();
	    	        panel.setLayout(new GridLayout(2,1));
	    	        panel.setPreferredSize(new Dimension(80,200));
	    	        OK.setPreferredSize(new Dimension(60,80));
	    	        cancel.setPreferredSize(new Dimension(60,80));
	    	        panel.add(OK);
	    	        panel.add(cancel);
	    	        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Volume"));
	    	        frame.add(panel,BorderLayout.CENTER);
	    	        frame.pack();
	    	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    	        frame.setVisible(true);
	    	        frame.setResizable(false);
	        } } );
        //4 create a radio buttons and add them to a speakergroup
        speakeron = new JRadioButton("On");
        speakeroff = new JRadioButton("Off");
        speakergroup = new ButtonGroup();
        speakergroup.add(speakeron);
        speakergroup.add(speakeroff);
        //5 create a speakerpanel with its appropriate type, set its layout and add radio buttons to it without using speakergroup object
        JPanel speakerpanel = new JPanel();
        speakerpanel.add(speakeron);
        speakerpanel.add(speakeroff);
        speakeron.setPreferredSize(new Dimension(60,80));
        speakeroff.setPreferredSize(new Dimension(60,80));
        //6 to your opinion what is the result of the following statement
        speakerpanel.setLayout(new GridLayout(2,1));
        speakerpanel.setPreferredSize(new Dimension(80,200));
        speakerpanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Speaker"));
        //7 add the speakerpanel to the Gui
        this.add(speakerpanel,BorderLayout.EAST);
        /******************Volume Part********************/
        //8 create volume buttons
        volumeup = new JButton("Up");
        volumedown = new JButton("Down");
        //9 create a volumepanel with its appropriate type, set its layout, add volume buttons to it
        JPanel volumepanel = new JPanel();
        volumepanel.setLayout(new GridLayout(2,1));
        volumepanel.setPreferredSize(new Dimension(80,200));
        volumeup.setPreferredSize(new Dimension(60,80));
        volumedown.setPreferredSize(new Dimension(60,80));
        volumepanel.add(volumeup);
        volumepanel.add(volumedown);
        volumepanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Volume"));
        this.add(volumepanel,BorderLayout.WEST);
        //10 add the volumepanel to the Gui
        /******************Digit Part********************/
        //11 create digit buttons
        JPanel digitPanel = new JPanel();
        digitPanel.setLayout(new GridLayout(4,3));
        addButton("1",digitPanel);
        addButton("2",digitPanel);
        addButton("3",digitPanel);
        addButton("4",digitPanel);
        addButton("5",digitPanel);
        addButton("6",digitPanel);
        addButton("7",digitPanel);
        addButton("8",digitPanel);
        addButton("9",digitPanel);
        addButton("*",digitPanel);
        addButton("0",digitPanel);
        addButton("#",digitPanel);
        this.add(digitPanel,BorderLayout.CENTER);
        //12 create a digitpanel for the digit buttons set its layout and add digits into this panel
        //13 add the digitpanel to the Gui
        /******************Gui Options Part********************/
        //14 set the title of the window its size to 400,400 and make it visible
        this.pack();
    }

    public void addButton(String name, JPanel Panel){
        JButton a = new JButton(name);
        a.setPreferredSize(new Dimension(80,50));
        Panel.add(a);
	    a.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	              //insert the action here
	    		  //JFrame frame = new JFrame(" JButton listener");
	              //JDialog d = new JDialog(frame, "Button Pressed", true);
	              // d.setLocationRelativeTo(frame);
	              //d.setVisible(true);
	        	  String keyvalue = e.getActionCommand();
	              screen.setText(screen.getText()+ keyvalue);
	        }
	    } );
    	}

 }