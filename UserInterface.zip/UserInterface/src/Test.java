
import javax.swing.*;
import java.awt.*;

public class Test {
    public static void main(String[] args) {
        EventQueue.invokeLater(()->{
            Gui a = new Gui();
            a.setTitle("Phone Application");
            a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            a.setVisible(true);
            a.setResizable(false);
        });
    }

}